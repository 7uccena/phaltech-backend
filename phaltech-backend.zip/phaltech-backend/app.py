import os
import re
from flask import Flask, request, redirect, url_for, send_from_directory
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__, static_folder='.')
CORS(app)

SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USERNAME = os.environ.get("SMTP_USERNAME")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD")

def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

@app.route('/')
def serve_index():
    return "API da PHAL TECH online!"

@app.route('/submit-contact', methods=['POST'])
def submit_contact():
    data = request.form

    name = data.get('name')
    email = data.get('email')
    subject = data.get('subject')
    message_body = data.get('message')

    if not all([name, email, subject, message_body]):
        return {"status": "error", "message": "missing_fields"}, 400

    if not is_valid_email(email):
        return {"status": "error", "message": "invalid_email"}, 400

    email_content = f"""
Nome: {name}
E-mail: {email}
Assunto: {subject}
Mensagem:
{message_body}
"""

    msg = MIMEText(email_content)
    msg['Subject'] = f"[Contato Site] {subject}"
    msg['From'] = SMTP_USERNAME
    msg['To'] = SMTP_USERNAME

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SMTP_USERNAME, SMTP_USERNAME, msg.as_string())
        server.quit()
        return {"status": "success", "message": "Mensagem enviada com sucesso!"}
    except Exception as e:
        print(f"Erro no envio SMTP: {e}")
        return {"status": "error", "message": "smtp_error"}, 500

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)
